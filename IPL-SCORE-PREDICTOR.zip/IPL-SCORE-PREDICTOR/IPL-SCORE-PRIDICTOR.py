from tkinter import *
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR

# Constants
TEAMS = ['Chennai Super Kings', 'Delhi Daredevils', 'Kings XI Punjab',
         'Kolkata Knight Riders', 'Mumbai Indians', 'Rajasthan Royals',
         'Royal Challengers Bangalore', 'Sunrisers Hyderabad']

def prepare_data():
    # Load and prepare data
    data = pd.read_csv("data.csv")
    
    # Remove irrelevant columns (keeping venue)
    irrelevant = ['mid', 'date', 'batsman', 'bowler', 'striker', 'non-striker']
    data = data.drop(irrelevant, axis=1)
    
    # Keep only consistent teams
    data = data[(data['batting_team'].isin(TEAMS)) & (data['bowling_team'].isin(TEAMS))]
    
    # Remove first 5 overs
    data = data[data['overs'] >= 5.0]
    
    # Get unique venues
    venues = sorted(data['venue'].unique())
    
    # Perform one-hot encoding
    batting_dummies = pd.get_dummies(data['batting_team'], prefix='batting_team')
    bowling_dummies = pd.get_dummies(data['bowling_team'], prefix='bowling_team')
    venue_dummies = pd.get_dummies(data['venue'], prefix='venue')
    
    # Combine features
    features = pd.concat([
        batting_dummies, 
        bowling_dummies,
        venue_dummies,
        data[['runs', 'wickets', 'overs', 'runs_last_5', 'wickets_last_5']]
    ], axis=1)
    
    labels = data['total']
    
    return train_test_split(features, labels, test_size=0.2, shuffle=True), venues

def predict_score(batting_team, bowling_team, venue, runs, wickets, overs, runs_last_5, wickets_last_5, model, venues):
    prediction_array = []
    
    # One-hot encoding for batting team
    for team in TEAMS:
        prediction_array.append(1 if batting_team == team else 0)
    
    # One-hot encoding for bowling team
    for team in TEAMS:
        prediction_array.append(1 if bowling_team == team else 0)
    
    # One-hot encoding for venue
    for v in venues:
        prediction_array.append(1 if venue == v else 0)
    
    # Add other features
    prediction_array.extend([runs, wickets, overs, runs_last_5, wickets_last_5])
    prediction_array = np.array([prediction_array])
    
    return int(round(model.predict(prediction_array)[0]))

# Train models
(X_train, X_test, y_train, y_test), VENUES = prepare_data()

# Initialize models
forest = RandomForestRegressor()
forest.fit(X_train, y_train)

linreg = LinearRegression()
linreg.fit(X_train, y_train)

tree = DecisionTreeRegressor()
tree.fit(X_train, y_train)

svm = SVR()
svm.fit(X_train, y_train)

def RandomForest():
    try:
        runs = float(RunsEntry.get())
        wickets = float(WicketsEntry.get())
        overs = float(OversEntry.get())
        runs_last_5 = float(RunsLast5Entry.get())
        wickets_last_5 = float(WicketsLast5Entry.get())
        
        prediction = predict_score(
            BattingTeam.get(),
            BowlingTeam.get(),
            Venue.get(),
            runs, wickets, overs,
            runs_last_5, wickets_last_5,
            forest, VENUES
        )
        
        t1.delete("1.0", END)
        t1.insert(END, f"Predicted Score: {prediction}")
    except:
        t1.delete("1.0", END)
        t1.insert(END, "Invalid Input")

def LinearRegression():
    try:
        runs = float(RunsEntry.get())
        wickets = float(WicketsEntry.get())
        overs = float(OversEntry.get())
        runs_last_5 = float(RunsLast5Entry.get())
        wickets_last_5 = float(WicketsLast5Entry.get())
        
        prediction = predict_score(
            BattingTeam.get(),
            BowlingTeam.get(),
            Venue.get(),
            runs, wickets, overs,
            runs_last_5, wickets_last_5,
            linreg, VENUES
        )
        
        t2.delete("1.0", END)
        t2.insert(END, f"Predicted Score: {prediction}")
    except:
        t2.delete("1.0", END)
        t2.insert(END, "Invalid Input")

def DecisionTree():
    try:
        runs = float(RunsEntry.get())
        wickets = float(WicketsEntry.get())
        overs = float(OversEntry.get())
        runs_last_5 = float(RunsLast5Entry.get())
        wickets_last_5 = float(WicketsLast5Entry.get())
        
        prediction = predict_score(
            BattingTeam.get(),
            BowlingTeam.get(),
            Venue.get(),
            runs, wickets, overs,
            runs_last_5, wickets_last_5,
            tree, VENUES
        )
        
        t3.delete("1.0", END)
        t3.insert(END, f"Predicted Score: {prediction}")
    except:
        t3.delete("1.0", END)
        t3.insert(END, "Invalid Input")

# GUI Setup
root = Tk()
root.title("IPL Score Prediction System")
root.configure(bg="#F5F5F5")

# Title
title = Label(root, text="IPL Score Predictor using Machine Learning", bg="#5B9BD5", 
              fg="white", font=("Arial", 20, "bold"))
title.grid(row=0, columnspan=3, padx=100, pady=20)

# Input Fields
Label(root, text="Batting Team", bg="#F5F5F5", font=("Arial", 12)).grid(row=1, column=0, pady=5, sticky=W)
BattingTeam = StringVar(root)
BattingTeam.set(TEAMS[0])
OptionMenu(root, BattingTeam, *TEAMS).grid(row=1, column=1, padx=10, pady=5)

Label(root, text="Bowling Team", bg="#F5F5F5", font=("Arial", 12)).grid(row=2, column=0, pady=5, sticky=W)
BowlingTeam = StringVar(root)
BowlingTeam.set(TEAMS[1])
OptionMenu(root, BowlingTeam, *TEAMS).grid(row=2, column=1, padx=10, pady=5)

# Venue dropdown
Label(root, text="Venue", bg="#F5F5F5", font=("Arial", 12)).grid(row=3, column=0, pady=5, sticky=W)
Venue = StringVar(root)
Venue.set(VENUES[0])
OptionMenu(root, Venue, *VENUES).grid(row=3, column=1, padx=10, pady=5)

# Numerical inputs
labels = ['Current Runs', 'Wickets', 'Overs', 'Runs (Last 5 overs)', 'Wickets (Last 5 overs)']
entries = ['RunsEntry', 'WicketsEntry', 'OversEntry', 'RunsLast5Entry', 'WicketsLast5Entry']

for idx, (label, entry) in enumerate(zip(labels, entries), start=4):
    Label(root, text=label, bg="#F5F5F5", font=("Arial", 12)).grid(row=idx, column=0, pady=5, sticky=W)
    globals()[entry] = Entry(root, width=20)
    globals()[entry].grid(row=idx, column=1, padx=10, pady=5)

# Prediction Buttons
Button(root, text="Random Forest", command=RandomForest, bg="#4CAF50", fg="white", 
       font=("Arial", 12, "bold"), width=20).grid(row=9, column=0, padx=10, pady=20)
Button(root, text="Linear Regression", command=LinearRegression, bg="#2196F3", fg="white", 
       font=("Arial", 12, "bold"), width=20).grid(row=9, column=1, padx=10, pady=20)
Button(root, text="Decision Tree", command=DecisionTree, bg="#FF5722", fg="white", 
       font=("Arial", 12, "bold"), width=20).grid(row=9, column=2, padx=10, pady=20)

# Result Text Areas
t1 = Text(root, height=2, width=40, font=("Arial", 12))
t1.grid(row=10, column=0, padx=10, pady=10)

t2 = Text(root, height=2, width=40, font=("Arial", 12))
t2.grid(row=10, column=1, padx=10, pady=10)

t3 = Text(root, height=2, width=40, font=("Arial", 12))
t3.grid(row=10, column=2, padx=10, pady=10)

root.mainloop()
